import { type NextRequest, NextResponse } from "next/server"
import { emailService } from "@/lib/email-service"

export async function POST(request: NextRequest) {
  try {
    const { email, userName } = await request.json()

    // Validate input
    if (!email || !userName) {
      return NextResponse.json({ error: "Missing required fields: email, userName" }, { status: 400 })
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json({ error: "Invalid email format" }, { status: 400 })
    }

    // Send welcome email
    const emailSent = await emailService.sendWelcomeEmail(email, userName)

    if (!emailSent) {
      return NextResponse.json({ error: "Failed to send welcome email" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Welcome email sent successfully",
    })
  } catch (error) {
    console.error("API Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
