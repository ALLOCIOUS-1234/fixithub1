"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Globe,
  Users,
  MessageSquare,
  Shield,
  CheckCircle,
  Star,
  ArrowRight,
  MapPin,
  Camera,
  Bell,
  Smartphone,
  Building,
  Heart,
  TrendingUp,
  Play,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"

const stats = [
  { number: "50K+", label: "Issues Resolved", icon: CheckCircle },
  { number: "120+", label: "Countries", icon: Globe },
  { number: "1M+", label: "Active Users", icon: Users },
  { number: "500+", label: "Government Partners", icon: Building },
]

const features = [
  {
    icon: Camera,
    title: "Photo Evidence",
    description: "Take photos of issues with automatic location tagging for accurate reporting",
  },
  {
    icon: MapPin,
    title: "GPS Location",
    description: "Automatic geolocation ensures authorities know exactly where the problem is",
  },
  {
    icon: Bell,
    title: "Real-time Updates",
    description: "Get notified when your reported issues are being addressed or resolved",
  },
  {
    icon: MessageSquare,
    title: "Community Engagement",
    description: "Comment, support, and collaborate with others on community issues",
  },
  {
    icon: Shield,
    title: "Direct Authority Contact",
    description: "Reports go directly to relevant authorities like MPs, KENHAA, KURA, and more",
  },
  {
    icon: TrendingUp,
    title: "Impact Tracking",
    description: "See your contribution to community improvement with detailed analytics",
  },
]

const partners = [
  { name: "Kenya National Highways Authority", logo: "/placeholder.svg?height=60&width=120", type: "KENHAA" },
  { name: "Kenya Urban Roads Authority", logo: "/placeholder.svg?height=60&width=120", type: "KURA" },
  { name: "Ministry of Health", logo: "/placeholder.svg?height=60&width=120", type: "Health" },
  { name: "Ministry of Education", logo: "/placeholder.svg?height=60&width=120", type: "Education" },
  { name: "County Governments", logo: "/placeholder.svg?height=60&width=120", type: "Counties" },
  { name: "Parliament of Kenya", logo: "/placeholder.svg?height=60&width=120", type: "Parliament" },
]

const testimonials = [
  {
    name: "Sarah Wanjiku",
    role: "Community Leader, Nairobi",
    avatar: "/placeholder.svg?height=50&width=50",
    content:
      "Universe helped us get our road fixed in just 2 weeks. The direct connection to KENHAA made all the difference!",
    rating: 5,
  },
  {
    name: "John Mwangi",
    role: "Citizen, Mombasa",
    avatar: "/placeholder.svg?height=50&width=50",
    content:
      "Finally, a platform where our voices are heard. Reported a water issue and got updates throughout the resolution process.",
    rating: 5,
  },
  {
    name: "Grace Akinyi",
    role: "Teacher, Kisumu",
    avatar: "/placeholder.svg?height=50&width=50",
    content: "The school drainage problem we reported was resolved within a month. Universe really works!",
    rating: 5,
  },
]

const categories = [
  { name: "Roads & Infrastructure", icon: "🛣️", count: "15,234 issues" },
  { name: "Waste Management", icon: "♻️", count: "8,567 issues" },
  { name: "Water & Sanitation", icon: "💧", count: "6,789 issues" },
  { name: "Health Services", icon: "🏥", count: "4,321 issues" },
  { name: "Education", icon: "🎓", count: "3,456 issues" },
  { name: "Security", icon: "🛡️", count: "2,890 issues" },
]

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">U</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Universe
              </h1>
              <p className="text-xs text-gray-500">Global Issue Resolution Platform</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="outline">Sign In</Button>
            </Link>
            <Link href="/login">
              <Button className="bg-gradient-to-r from-purple-500 to-pink-500">Get Started</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 py-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <Badge className="mb-6 bg-purple-100 text-purple-800 hover:bg-purple-100">
            🌍 Now Available in 120+ Countries
          </Badge>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-purple-600 via-pink-600 to-orange-600 bg-clip-text text-transparent">
            Your Voice,
            <br />
            Your Community,
            <br />
            Your Impact
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Universe connects citizens directly with government authorities to report, track, and resolve community
            issues. From potholes to waste management, your reports create real change.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/report">
              <Button size="lg" className="bg-gradient-to-r from-purple-500 to-pink-500 text-lg px-8 py-6">
                Start Reporting Issues
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="text-lg px-8 py-6 bg-transparent">
              <Play className="mr-2 w-5 h-5" />
              Watch Demo
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <stat.icon className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                <div className="text-3xl font-bold text-gray-900">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">How Universe Works</h2>
            <p className="text-xl text-gray-600">Simple, effective, and transparent issue resolution</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center p-6">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Camera className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">1. Report the Issue</h3>
              <p className="text-gray-600">
                Take a photo, add description, and let GPS automatically tag your location. Choose the right authority
                to report to.
              </p>
            </Card>

            <Card className="text-center p-6">
              <div className="w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Bell className="w-8 h-8 text-pink-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">2. Authority Gets Notified</h3>
              <p className="text-gray-600">
                Your report goes directly to the relevant authority - MP, KENHAA, KURA, or local government - with all
                details.
              </p>
            </Card>

            <Card className="text-center p-6">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">3. Track Progress</h3>
              <p className="text-gray-600">
                Get real-time updates as your issue moves from "Pending" to "Under Review" to "Resolved". Stay informed
                throughout.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Powerful Features for Real Change</h2>
            <p className="text-xl text-gray-600">Everything you need to make your community better</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                <feature.icon className="w-10 h-10 text-purple-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Issue Categories */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Report Any Community Issue</h2>
            <p className="text-xl text-gray-600">From infrastructure to public services - we've got you covered</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category, index) => (
              <Card key={index} className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                <div className="flex items-center gap-4">
                  <div className="text-3xl">{category.icon}</div>
                  <div>
                    <h3 className="font-semibold text-lg">{category.name}</h3>
                    <p className="text-gray-600 text-sm">{category.count}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Partners */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Trusted by Government Partners</h2>
            <p className="text-xl text-gray-600">Working directly with authorities to ensure your voice is heard</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center">
            {partners.map((partner, index) => (
              <Card key={index} className="p-4 text-center hover:shadow-lg transition-shadow">
                <Image
                  src={partner.logo || "/placeholder.svg"}
                  alt={partner.name}
                  width={120}
                  height={60}
                  className="mx-auto mb-2 grayscale hover:grayscale-0 transition-all"
                />
                <p className="text-xs text-gray-600 font-medium">{partner.type}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Real Stories, Real Impact</h2>
            <p className="text-xl text-gray-600">See how Universe is transforming communities worldwide</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="p-6">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">"{testimonial.content}"</p>
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={testimonial.avatar || "/placeholder.svg"} alt={testimonial.name} />
                    <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold">{testimonial.name}</p>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Make a Difference?</h2>
          <p className="text-xl mb-8 opacity-90">
            Join millions of citizens worldwide who are using Universe to improve their communities
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/login">
              <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100 text-lg px-8 py-6">
                Get Started Free
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-purple-600 text-lg px-8 py-6 bg-transparent"
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold">U</span>
                </div>
                <span className="text-xl font-bold">Universe</span>
              </div>
              <p className="text-gray-400 mb-4">
                Empowering communities worldwide to report and resolve issues together.
              </p>
              <div className="flex gap-4">
                <Button size="sm" variant="outline" className="border-gray-600 text-gray-400 bg-transparent">
                  <Smartphone className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="outline" className="border-gray-600 text-gray-400 bg-transparent">
                  <Heart className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="outline" className="border-gray-600 text-gray-400 bg-transparent">
                  <Globe className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Platform</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/login" className="hover:text-white">
                    Sign Up
                  </Link>
                </li>
                <li>
                  <Link href="/login" className="hover:text-white">
                    Sign In
                  </Link>
                </li>
                <li>
                  <Link href="/report" className="hover:text-white">
                    Report Issue
                  </Link>
                </li>
                <li>
                  <Link href="/explore" className="hover:text-white">
                    Explore
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-white">
                    Help Center
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Contact Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Community Guidelines
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Privacy Policy
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-white">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Careers
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Press
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Partners
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">© 2024 Universe - Global Issue Resolution Platform</p>
            <p className="text-gray-400 text-sm">
              CEO: <span className="font-semibold text-white">ALLOCIOUS KIPROP</span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
