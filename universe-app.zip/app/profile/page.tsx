"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Settings, Edit, MapPin, Calendar, TrendingUp, ArrowLeft, Home, Plus, User, Search } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

const userStats = {
  issuesReported: 12,
  issuesResolved: 8,
  communitiesHelped: 5,
  reputation: 850,
}

const userIssues = [
  {
    id: 1,
    title: "Pothole on Main Street",
    category: "Roads - KENHAA",
    status: "Resolved",
    date: "2024-01-15",
    image: "/placeholder.svg?height=100&width=150",
  },
  {
    id: 2,
    title: "Broken streetlight",
    category: "MP Office",
    status: "Under Review",
    date: "2024-01-10",
    image: "/placeholder.svg?height=100&width=150",
  },
  {
    id: 3,
    title: "Garbage collection delay",
    category: "Waste Management",
    status: "Pending",
    date: "2024-01-08",
    image: "/placeholder.svg?height=100&width=150",
  },
]

const achievements = [
  { name: "First Reporter", description: "Reported your first issue", icon: "🏆" },
  { name: "Community Helper", description: "Helped resolve 5 community issues", icon: "🤝" },
  { name: "Active Citizen", description: "Reported 10+ issues", icon: "⭐" },
  { name: "Problem Solver", description: "5 issues you reported were resolved", icon: "✅" },
]

export default function ProfilePage() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Resolved":
        return "bg-green-500"
      case "Under Review":
        return "bg-yellow-500"
      case "Pending":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">U</span>
            </div>
            <h1 className="text-xl font-bold">Profile</h1>
          </div>
          <Button variant="outline" size="sm" className="ml-auto bg-transparent">
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-6 pb-20">
        {/* Profile Header */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <Avatar className="w-20 h-20">
                <AvatarImage src="/placeholder.svg?height=80&width=80" alt="User" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h2 className="text-2xl font-bold">John Doe</h2>
                  <Badge className="bg-purple-500">Active Citizen</Badge>
                </div>
                <p className="text-gray-600 mb-2">@johndoe • Joined January 2024</p>
                <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    <span>Nairobi, Kenya</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    <span>Member since Jan 2024</span>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Profile
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{userStats.issuesReported}</div>
              <div className="text-sm text-gray-600">Issues Reported</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 text-center">
              <div className="text-2xl font-bold text-green-600">{userStats.issuesResolved}</div>
              <div className="text-sm text-gray-600">Issues Resolved</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{userStats.communitiesHelped}</div>
              <div className="text-sm text-gray-600">Communities Helped</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{userStats.reputation}</div>
              <div className="text-sm text-gray-600">Reputation Points</div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="issues" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="issues">My Issues</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="issues" className="space-y-4">
            {userIssues.map((issue) => (
              <Card key={issue.id}>
                <CardContent className="pt-4">
                  <div className="flex gap-4">
                    <Image
                      src={issue.image || "/placeholder.svg"}
                      alt={issue.title}
                      width={150}
                      height={100}
                      className="w-24 h-16 object-cover rounded"
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold">{issue.title}</h3>
                        <Badge className={`text-white ${getStatusColor(issue.status)}`}>{issue.status}</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{issue.category}</p>
                      <p className="text-xs text-gray-500">Reported on {issue.date}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="achievements" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              {achievements.map((achievement, index) => (
                <Card key={index}>
                  <CardContent className="pt-4">
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">{achievement.icon}</div>
                      <div>
                        <h3 className="font-semibold">{achievement.name}</h3>
                        <p className="text-sm text-gray-600">{achievement.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="activity" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-sm">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span>Your issue "Pothole on Main Street" was marked as resolved</span>
                    <span className="text-gray-500 ml-auto">2 hours ago</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>You commented on "Broken streetlight" issue</span>
                    <span className="text-gray-500 ml-auto">1 day ago</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <span>You reported a new issue "Garbage collection delay"</span>
                    <span className="text-gray-500 ml-auto">3 days ago</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    <span>You earned the "Active Citizen" achievement</span>
                    <span className="text-gray-500 ml-auto">1 week ago</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t">
        <div className="max-w-4xl mx-auto px-4 py-2">
          <div className="flex items-center justify-around">
            <Link href="/">
              <Button variant="ghost" size="sm" className="flex flex-col items-center gap-1 h-auto py-2">
                <Home className="w-5 h-5" />
                <span className="text-xs">Home</span>
              </Button>
            </Link>
            <Link href="/explore">
              <Button variant="ghost" size="sm" className="flex flex-col items-center gap-1 h-auto py-2">
                <Search className="w-5 h-5" />
                <span className="text-xs">Explore</span>
              </Button>
            </Link>
            <Link href="/report">
              <Button
                size="sm"
                className="flex flex-col items-center gap-1 h-auto py-2 bg-gradient-to-r from-purple-500 to-pink-500"
              >
                <Plus className="w-5 h-5" />
                <span className="text-xs">Report</span>
              </Button>
            </Link>
            <Button variant="default" size="sm" className="flex flex-col items-center gap-1 h-auto py-2">
              <User className="w-5 h-5" />
              <span className="text-xs">Profile</span>
            </Button>
          </div>
        </div>
      </nav>
    </div>
  )
}
