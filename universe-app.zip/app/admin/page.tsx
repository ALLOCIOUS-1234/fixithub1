"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Shield,
  Users,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  Settings,
  Search,
  Filter,
  Eye,
  MessageSquare,
  Ban,
  UserCheck,
  BarChart3,
  MapPin,
  Calendar,
  ArrowLeft,
  Plus,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"

const adminStats = {
  totalIssues: 1247,
  pendingIssues: 89,
  resolvedIssues: 1058,
  activeUsers: 3456,
  newReports: 23,
  criticalIssues: 12,
}

const recentIssues = [
  {
    id: 1,
    title: "Major road collapse on Highway A1",
    user: "John Doe",
    category: "Roads - KENHAA",
    priority: "Critical",
    status: "Pending",
    location: "Nairobi, Kenya",
    reportedAt: "2024-01-15 14:30",
    image: "/placeholder.svg?height=60&width=80",
  },
  {
    id: 2,
    title: "Water contamination in residential area",
    user: "Sarah Wilson",
    category: "Water Services",
    priority: "High",
    status: "Under Review",
    location: "Mombasa, Kenya",
    reportedAt: "2024-01-15 12:15",
    image: "/placeholder.svg?height=60&width=80",
  },
  {
    id: 3,
    title: "Illegal dumping site causing health hazards",
    user: "Mike Johnson",
    category: "Waste Management",
    priority: "High",
    status: "Escalated",
    location: "Kisumu, Kenya",
    reportedAt: "2024-01-15 10:45",
    image: "/placeholder.svg?height=60&width=80",
  },
  {
    id: 4,
    title: "Street lighting failure in CBD",
    user: "Grace Wanjiku",
    category: "MP Office",
    priority: "Medium",
    status: "Assigned",
    location: "Eldoret, Kenya",
    reportedAt: "2024-01-15 09:20",
    image: "/placeholder.svg?height=60&width=80",
  },
]

const activeUsers = [
  {
    id: 1,
    name: "John Doe",
    email: "john@example.com",
    role: "Citizen",
    issuesReported: 12,
    joinDate: "2024-01-01",
    status: "Active",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 2,
    name: "Sarah Wilson",
    email: "sarah@example.com",
    role: "Community Leader",
    issuesReported: 28,
    joinDate: "2023-12-15",
    status: "Active",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 3,
    name: "Mike Johnson",
    email: "mike@example.com",
    role: "Citizen",
    issuesReported: 8,
    joinDate: "2024-01-10",
    status: "Suspended",
    avatar: "/placeholder.svg?height=40&width=40",
  },
]

const departments = [
  { name: "MP Offices", issues: 234, resolved: 198, pending: 36 },
  { name: "KENHAA", issues: 189, resolved: 156, pending: 33 },
  { name: "KURA", issues: 167, resolved: 142, pending: 25 },
  { name: "Waste Management", issues: 298, resolved: 267, pending: 31 },
  { name: "Water Services", issues: 156, resolved: 134, pending: 22 },
  { name: "Health Services", issues: 123, resolved: 108, pending: 15 },
]

export default function AdminPage() {
  const [selectedTab, setSelectedTab] = useState("dashboard")
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [userEmail, setUserEmail] = useState("")
  const router = useRouter()
  const [showPartnerForm, setShowPartnerForm] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [success, setSuccess] = useState("")
  const [error, setError] = useState("")

  const registeredPartners = [
    {
      id: 1,
      name: "Kenya Urban Roads Authority",
      acronym: "KURA",
      type: "Authority",
      category: "Roads & Infrastructure",
      description: "Responsible for urban roads development and maintenance",
      contactEmail: "info@kura.go.ke",
      contactPhone: "+254 20 2729200",
      website: "https://www.kura.go.ke",
      jurisdiction: "Urban Areas Nationwide",
      address: "KURA Towers, Upperhill, Nairobi",
      status: "Active",
      registeredAt: "2024-01-15",
    },
    {
      id: 2,
      name: "Kenya National Highways Authority",
      acronym: "KENHAA",
      type: "Authority",
      category: "Roads & Infrastructure",
      description: "Manages national highways and trunk roads",
      contactEmail: "info@kenha.co.ke",
      contactPhone: "+254 20 2729300",
      website: "https://www.kenha.co.ke",
      jurisdiction: "National Highways",
      address: "Barabara Plaza, Nairobi",
      status: "Active",
      registeredAt: "2024-01-10",
    },
    {
      id: 3,
      name: "Ministry of Health",
      acronym: "MOH",
      type: "Ministry",
      category: "Health Services",
      description: "National health policy and service delivery",
      contactEmail: "ps@health.go.ke",
      contactPhone: "+254 20 2717077",
      website: "https://www.health.go.ke",
      jurisdiction: "Nationwide",
      address: "Afya House, Cathedral Road, Nairobi",
      status: "Active",
      registeredAt: "2024-01-08",
    },
  ]

  const handlePartnerSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Simulate API call to register partner
      await new Promise((resolve) => setTimeout(resolve, 2000))

      setSuccess("Partner registered successfully!")
      setShowPartnerForm(false)

      // Reset form
      e.currentTarget.reset()

      setTimeout(() => setSuccess(""), 3000)
    } catch (err) {
      setError("Failed to register partner. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    // Check if user is authenticated as admin
    const userRole = localStorage.getItem("userRole")
    const email = localStorage.getItem("userEmail")

    if (userRole !== "admin" || email !== "txichub39@gmail.com") {
      router.push("/login")
      return
    }

    setIsAuthenticated(true)
    setUserEmail(email)
  }, [router])

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Critical":
        return "bg-red-600"
      case "High":
        return "bg-orange-500"
      case "Medium":
        return "bg-yellow-500"
      case "Low":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Resolved":
        return "bg-green-500"
      case "Under Review":
        return "bg-blue-500"
      case "Escalated":
        return "bg-orange-500"
      case "Assigned":
        return "bg-purple-500"
      case "Pending":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const getUserStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-500"
      case "Suspended":
        return "bg-red-500"
      case "Inactive":
        return "bg-gray-500"
      default:
        return "bg-gray-500"
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("userRole")
    localStorage.removeItem("userEmail")
    router.push("/landing")
  }

  // Show loading or redirect if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <Card className="w-full max-w-md text-center">
          <CardContent className="pt-6">
            <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Admin Access Required</h2>
            <p className="text-gray-600 mb-4">You need admin privileges to access this page.</p>
            <Link href="/login">
              <Button className="w-full bg-gradient-to-r from-red-500 to-orange-500">Admin Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-4">
          <Link href="/landing">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-r from-red-500 to-orange-500 rounded-lg flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold">Admin Dashboard</h1>
          </div>
          <div className="ml-auto flex items-center gap-4">
            <Badge className="bg-red-100 text-red-800">{adminStats.criticalIssues} Critical Issues</Badge>
            <Avatar className="w-8 h-8">
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Admin" />
              <AvatarFallback>AK</AvatarFallback>
            </Avatar>
            <div className="text-sm">
              <p className="font-semibold">ALLOCIOUS KIPROP</p>
              <p className="text-gray-500 text-xs">{userEmail}</p>
            </div>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Admin Alert */}
      <div className="max-w-7xl mx-auto px-4 py-4">
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="w-4 h-4 text-green-600" />
          <AlertDescription className="text-green-600">
            Welcome back, Admin! You have full access to monitor and manage all platform activities.
          </AlertDescription>
        </Alert>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="issues">Issues</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="departments">Departments</TabsTrigger>
            <TabsTrigger value="partners">Partners</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <Card>
                <CardContent className="pt-4 text-center">
                  <AlertTriangle className="w-8 h-8 text-orange-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{adminStats.totalIssues}</div>
                  <div className="text-sm text-gray-600">Total Issues</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4 text-center">
                  <Clock className="w-8 h-8 text-red-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{adminStats.pendingIssues}</div>
                  <div className="text-sm text-gray-600">Pending</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4 text-center">
                  <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{adminStats.resolvedIssues}</div>
                  <div className="text-sm text-gray-600">Resolved</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4 text-center">
                  <Users className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{adminStats.activeUsers}</div>
                  <div className="text-sm text-gray-600">Active Users</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4 text-center">
                  <TrendingUp className="w-8 h-8 text-purple-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{adminStats.newReports}</div>
                  <div className="text-sm text-gray-600">New Today</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4 text-center">
                  <Shield className="w-8 h-8 text-red-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{adminStats.criticalIssues}</div>
                  <div className="text-sm text-gray-600">Critical</div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Issues */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5" />
                  Recent Critical Issues
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentIssues.slice(0, 3).map((issue) => (
                    <div key={issue.id} className="flex items-center gap-4 p-3 border rounded-lg">
                      <Image
                        src={issue.image || "/placeholder.svg"}
                        alt={issue.title}
                        width={80}
                        height={60}
                        className="w-16 h-12 object-cover rounded"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold">{issue.title}</h3>
                        <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
                          <span>by {issue.user}</span>
                          <span>•</span>
                          <span>{issue.category}</span>
                          <span>•</span>
                          <MapPin className="w-3 h-3" />
                          <span>{issue.location}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={`text-white ${getPriorityColor(issue.priority)}`}>{issue.priority}</Badge>
                        <Badge className={`text-white ${getStatusColor(issue.status)}`}>{issue.status}</Badge>
                        <Button size="sm" variant="outline">
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Issues Tab */}
          <TabsContent value="issues" className="space-y-6">
            {/* Filters */}
            <Card>
              <CardContent className="pt-4">
                <div className="flex gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search issues..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="review">Under Review</SelectItem>
                      <SelectItem value="escalated">Escalated</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline">
                    <Filter className="w-4 h-4 mr-2" />
                    More Filters
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Issues List */}
            <Card>
              <CardHeader>
                <CardTitle>All Issues</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentIssues.map((issue) => (
                    <div key={issue.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-gray-50">
                      <Image
                        src={issue.image || "/placeholder.svg"}
                        alt={issue.title}
                        width={80}
                        height={60}
                        className="w-20 h-15 object-cover rounded"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{issue.title}</h3>
                        <div className="flex items-center gap-3 text-sm text-gray-600 mt-1">
                          <span>Reporter: {issue.user}</span>
                          <span>•</span>
                          <span>{issue.category}</span>
                          <span>•</span>
                          <MapPin className="w-3 h-3" />
                          <span>{issue.location}</span>
                          <span>•</span>
                          <Calendar className="w-3 h-3" />
                          <span>{issue.reportedAt}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={`text-white ${getPriorityColor(issue.priority)}`}>{issue.priority}</Badge>
                        <Badge className={`text-white ${getStatusColor(issue.status)}`}>{issue.status}</Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <MessageSquare className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Settings className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activeUsers.map((user) => (
                    <div key={user.id} className="flex items-center gap-4 p-4 border rounded-lg">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="font-semibold">{user.name}</h3>
                        <p className="text-sm text-gray-600">{user.email}</p>
                        <div className="flex items-center gap-3 text-sm text-gray-500 mt-1">
                          <span>Role: {user.role}</span>
                          <span>•</span>
                          <span>Issues: {user.issuesReported}</span>
                          <span>•</span>
                          <span>Joined: {user.joinDate}</span>
                        </div>
                      </div>
                      <Badge className={`text-white ${getUserStatusColor(user.status)}`}>{user.status}</Badge>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <UserCheck className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Ban className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Departments Tab */}
          <TabsContent value="departments" className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {departments.map((dept, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="text-lg">{dept.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Total Issues</span>
                        <span className="font-semibold">{dept.issues}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Resolved</span>
                        <span className="font-semibold text-green-600">{dept.resolved}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Pending</span>
                        <span className="font-semibold text-red-600">{dept.pending}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-green-500 h-2 rounded-full"
                          style={{ width: `${(dept.resolved / dept.issues) * 100}%` }}
                        ></div>
                      </div>
                      <div className="text-center text-sm text-gray-600">
                        {Math.round((dept.resolved / dept.issues) * 100)}% Resolution Rate
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Partners Tab */}
          <TabsContent value="partners" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold">Partner Management</h2>
                <p className="text-gray-600">Register and manage government partners and authorities</p>
              </div>
              <Button onClick={() => setShowPartnerForm(true)} className="bg-gradient-to-r from-purple-500 to-pink-500">
                <Plus className="w-4 h-4 mr-2" />
                Add New Partner
              </Button>
            </div>

            {/* Partner Registration Form */}
            {showPartnerForm && (
              <Card>
                <CardHeader>
                  <CardTitle>Register New Partner</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handlePartnerSubmit} className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="partnerName">Partner Name</Label>
                        <Input
                          id="partnerName"
                          name="partnerName"
                          placeholder="e.g., Kenya Urban Roads Authority"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="partnerAcronym">Acronym</Label>
                        <Input id="partnerAcronym" name="partnerAcronym" placeholder="e.g., KURA" required />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="partnerType">Partner Type</Label>
                        <Select name="partnerType" required>
                          <SelectTrigger>
                            <SelectValue placeholder="Select partner type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="government">Government Agency</SelectItem>
                            <SelectItem value="ministry">Ministry</SelectItem>
                            <SelectItem value="authority">Authority</SelectItem>
                            <SelectItem value="county">County Government</SelectItem>
                            <SelectItem value="parliament">Parliamentary Office</SelectItem>
                            <SelectItem value="utility">Utility Company</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="partnerCategory">Service Category</Label>
                        <Select name="partnerCategory" required>
                          <SelectTrigger>
                            <SelectValue placeholder="Select service category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="roads">Roads & Infrastructure</SelectItem>
                            <SelectItem value="waste">Waste Management</SelectItem>
                            <SelectItem value="water">Water & Sanitation</SelectItem>
                            <SelectItem value="health">Health Services</SelectItem>
                            <SelectItem value="education">Education</SelectItem>
                            <SelectItem value="security">Security</SelectItem>
                            <SelectItem value="mp">MP Office</SelectItem>
                            <SelectItem value="general">General Services</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="partnerDescription">Description</Label>
                      <Textarea
                        id="partnerDescription"
                        name="partnerDescription"
                        placeholder="Brief description of the partner's role and responsibilities"
                        rows={3}
                      />
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="contactEmail">Contact Email</Label>
                        <Input
                          id="contactEmail"
                          name="contactEmail"
                          type="email"
                          placeholder="official@partner.go.ke"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="contactPhone">Contact Phone</Label>
                        <Input id="contactPhone" name="contactPhone" type="tel" placeholder="+254 700 000 000" />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="website">Official Website</Label>
                        <Input id="website" name="website" type="url" placeholder="https://www.partner.go.ke" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="jurisdiction">Jurisdiction/Coverage</Label>
                        <Input
                          id="jurisdiction"
                          name="jurisdiction"
                          placeholder="e.g., Nationwide, Nairobi County, etc."
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="address">Physical Address</Label>
                      <Textarea
                        id="address"
                        name="address"
                        placeholder="Complete physical address including postal code"
                        rows={2}
                      />
                    </div>

                    <div className="flex gap-2 pt-4">
                      <Button
                        type="submit"
                        className="bg-gradient-to-r from-green-500 to-blue-500"
                        disabled={isLoading}
                      >
                        {isLoading ? "Registering..." : "Register Partner"}
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setShowPartnerForm(false)}>
                        Cancel
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            {/* Registered Partners List */}
            <Card>
              <CardHeader>
                <CardTitle>Registered Partners ({registeredPartners.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {registeredPartners.map((partner) => (
                    <div key={partner.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-gray-50">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-lg flex items-center justify-center">
                        <span className="text-white font-bold text-sm">{partner.acronym}</span>
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{partner.name}</h3>
                        <p className="text-sm text-gray-600">{partner.description}</p>
                        <div className="flex items-center gap-3 text-sm text-gray-500 mt-1">
                          <Badge variant="outline">{partner.type}</Badge>
                          <Badge variant="outline">{partner.category}</Badge>
                          <span>•</span>
                          <span>{partner.jurisdiction}</span>
                          <span>•</span>
                          <span>Registered: {partner.registeredAt}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={`text-white ${partner.status === "Active" ? "bg-green-500" : "bg-gray-500"}`}>
                          {partner.status}
                        </Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Settings className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <MessageSquare className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    Issue Trends
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    Chart visualization would go here
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    Resolution Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    Performance metrics would go here
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>System Health</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">98.5%</div>
                    <div className="text-sm text-gray-600">Uptime</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">1.2s</div>
                    <div className="text-sm text-gray-600">Avg Response</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">3,456</div>
                    <div className="text-sm text-gray-600">Active Sessions</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">23</div>
                    <div className="text-sm text-gray-600">Reports Today</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6 text-center">
          <div className="space-y-2">
            <p className="text-sm text-gray-600">© 2024 Universe Admin Panel - Global Issue Resolution Platform</p>
            <p className="text-xs text-gray-500">
              System Administrator: <span className="font-semibold">ALLOCIOUS KIPROP</span> ({userEmail})
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
