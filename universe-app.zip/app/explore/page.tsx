"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Search, Filter, MapPin, Clock, Heart, MessageCircle, ArrowLeft, Home, Plus, User } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

const categories = [
  "All",
  "Roads",
  "Waste Management",
  "MP Office",
  "Water Services",
  "Health",
  "Education",
  "Security",
]

const mockIssues = [
  {
    id: 1,
    user: { name: "Alice Johnson", avatar: "/placeholder.svg?height=40&width=40" },
    category: "Roads - KURA",
    title: "Broken traffic light at intersection",
    description: "Traffic light has been malfunctioning for 3 days causing accidents",
    image: "/placeholder.svg?height=200&width=300",
    location: "Eldoret, Kenya",
    timestamp: "1 hour ago",
    likes: 45,
    comments: 12,
    status: "Under Review",
  },
  {
    id: 2,
    user: { name: "David Mwangi", avatar: "/placeholder.svg?height=40&width=40" },
    category: "Waste Management",
    title: "Illegal dumping site",
    description: "People are dumping waste in this area creating environmental hazards",
    image: "/placeholder.svg?height=200&width=300",
    location: "Nakuru, Kenya",
    timestamp: "3 hours ago",
    likes: 67,
    comments: 23,
    status: "Pending",
  },
  {
    id: 3,
    user: { name: "Grace Wanjiku", avatar: "/placeholder.svg?height=40&width=40" },
    category: "Water Services",
    title: "Water shortage in residential area",
    description: "No water supply for over a week affecting hundreds of families",
    image: "/placeholder.svg?height=200&width=300",
    location: "Thika, Kenya",
    timestamp: "5 hours ago",
    likes: 89,
    comments: 34,
    status: "Escalated",
  },
  {
    id: 4,
    user: { name: "Peter Ochieng", avatar: "/placeholder.svg?height=40&width=40" },
    category: "Health Services",
    title: "Stagnant water breeding mosquitoes",
    description: "Large pool of stagnant water near school causing malaria outbreak risk",
    image: "/placeholder.svg?height=200&width=300",
    location: "Kisii, Kenya",
    timestamp: "8 hours ago",
    likes: 56,
    comments: 18,
    status: "Resolved",
  },
]

export default function ExplorePage() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [searchQuery, setSearchQuery] = useState("")

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Resolved":
        return "bg-green-500"
      case "Under Review":
        return "bg-yellow-500"
      case "Escalated":
        return "bg-orange-500"
      case "Pending":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const filteredIssues = mockIssues.filter((issue) => {
    const matchesCategory = selectedCategory === "All" || issue.category.includes(selectedCategory)
    const matchesSearch =
      issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.location.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">U</span>
            </div>
            <h1 className="text-xl font-bold">Explore Issues</h1>
          </div>
        </div>
      </header>

      {/* Search and Filters */}
      <div className="max-w-4xl mx-auto px-4 py-4 space-y-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search issues by title, description, or location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>

        {/* Category Filters */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className="whitespace-nowrap"
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Issues Grid */}
      <main className="max-w-4xl mx-auto px-4 pb-20">
        <div className="grid gap-4 md:grid-cols-2">
          {filteredIssues.map((issue) => (
            <Card key={issue.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <Image
                  src={issue.image || "/placeholder.svg"}
                  alt={issue.title}
                  width={300}
                  height={200}
                  className="w-full h-48 object-cover"
                />
                <Badge className={`absolute top-2 right-2 text-white ${getStatusColor(issue.status)}`}>
                  {issue.status}
                </Badge>
              </div>

              <CardHeader className="pb-2">
                <div className="flex items-center gap-2 mb-2">
                  <Avatar className="w-6 h-6">
                    <AvatarImage src={issue.user.avatar || "/placeholder.svg"} alt={issue.user.name} />
                    <AvatarFallback>{issue.user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <span className="text-sm text-gray-600">{issue.user.name}</span>
                  <Badge variant="outline" className="text-xs ml-auto">
                    {issue.category}
                  </Badge>
                </div>
                <h3 className="font-semibold text-lg leading-tight">{issue.title}</h3>
              </CardHeader>

              <CardContent className="pt-0">
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">{issue.description}</p>

                <div className="flex items-center gap-3 text-xs text-gray-500 mb-3">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    <span>{issue.location}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{issue.timestamp}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1 text-sm text-gray-600">
                      <Heart className="w-4 h-4" />
                      <span>{issue.likes}</span>
                    </div>
                    <div className="flex items-center gap-1 text-sm text-gray-600">
                      <MessageCircle className="w-4 h-4" />
                      <span>{issue.comments}</span>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredIssues.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">No issues found matching your criteria.</p>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t">
        <div className="max-w-4xl mx-auto px-4 py-2">
          <div className="flex items-center justify-around">
            <Link href="/">
              <Button variant="ghost" size="sm" className="flex flex-col items-center gap-1 h-auto py-2">
                <Home className="w-5 h-5" />
                <span className="text-xs">Home</span>
              </Button>
            </Link>
            <Button variant="default" size="sm" className="flex flex-col items-center gap-1 h-auto py-2">
              <Search className="w-5 h-5" />
              <span className="text-xs">Explore</span>
            </Button>
            <Link href="/report">
              <Button
                size="sm"
                className="flex flex-col items-center gap-1 h-auto py-2 bg-gradient-to-r from-purple-500 to-pink-500"
              >
                <Plus className="w-5 h-5" />
                <span className="text-xs">Report</span>
              </Button>
            </Link>
            <Link href="/profile">
              <Button variant="ghost" size="sm" className="flex flex-col items-center gap-1 h-auto py-2">
                <User className="w-5 h-5" />
                <span className="text-xs">Profile</span>
              </Button>
            </Link>
          </div>
        </div>
      </nav>
    </div>
  )
}
