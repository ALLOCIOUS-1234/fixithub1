import { emailService } from "../lib/email-service"

async function testEmailService() {
  console.log("🧪 Testing Universe Email Service...\n")

  try {
    // Test verification email
    console.log("📧 Testing verification email...")
    const verificationResult = await emailService.sendVerificationCode("test@example.com", "123456", "Test User")

    if (verificationResult) {
      console.log("✅ Verification email test passed")
    } else {
      console.log("❌ Verification email test failed")
    }

    // Test welcome email
    console.log("\n📧 Testing welcome email...")
    const welcomeResult = await emailService.sendWelcomeEmail("test@example.com", "Test User")

    if (welcomeResult) {
      console.log("✅ Welcome email test passed")
    } else {
      console.log("❌ Welcome email test failed")
    }

    console.log("\n🎉 Email service testing complete!")
  } catch (error) {
    console.error("❌ Email service test failed:", error)
  }
}

// Run the test
testEmailService()
