import { Resend } from "resend"

// Initialize Resend with your API key
const resend = new Resend("re_Pd79efJV_K7yZMbjBTbXPGWy5omyqHoW1")

export interface EmailOptions {
  to: string
  subject: string
  html: string
  from?: string
}

export class EmailService {
  private static instance: EmailService
  private fromEmail: string

  constructor() {
    // Use your admin email as the sender
    this.fromEmail = "txichub39@gmail.com"
  }

  static getInstance(): EmailService {
    if (!EmailService.instance) {
      EmailService.instance = new EmailService()
    }
    return EmailService.instance
  }

  async sendVerificationCode(email: string, code: string, userName: string): Promise<boolean> {
    try {
      const emailTemplate = this.getVerificationEmailTemplate(code, userName)

      const { data, error } = await resend.emails.send({
        from: `Universe Admin <${this.fromEmail}>`,
        to: [email],
        subject: "🌍 Verify Your Universe Account - Action Required",
        html: emailTemplate,
      })

      if (error) {
        console.error("Email sending error:", error)
        return false
      }

      console.log("Verification email sent successfully:", data)
      return true
    } catch (error) {
      console.error("Failed to send verification email:", error)
      return false
    }
  }

  async sendWelcomeEmail(email: string, userName: string): Promise<boolean> {
    try {
      const emailTemplate = this.getWelcomeEmailTemplate(userName)

      const { data, error } = await resend.emails.send({
        from: `Universe Team <${this.fromEmail}>`,
        to: [email],
        subject: "🎉 Welcome to Universe - Your Account is Ready!",
        html: emailTemplate,
      })

      if (error) {
        console.error("Welcome email sending error:", error)
        return false
      }

      console.log("Welcome email sent successfully:", data)
      return true
    } catch (error) {
      console.error("Failed to send welcome email:", error)
      return false
    }
  }

  private getVerificationEmailTemplate(code: string, userName: string): string {
    return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verify Your Universe Account</title>
        <style>
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                line-height: 1.6; 
                color: #333; 
                max-width: 600px; 
                margin: 0 auto; 
                padding: 0; 
                background-color: #f8fafc;
            }
            .container {
                background: white;
                border-radius: 12px;
                overflow: hidden;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                margin: 20px;
            }
            .header { 
                background: linear-gradient(135deg, #8B5CF6, #EC4899); 
                color: white; 
                padding: 40px 30px; 
                text-align: center; 
            }
            .logo { 
                font-size: 32px; 
                font-weight: bold; 
                margin-bottom: 10px; 
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
            }
            .logo-icon {
                width: 40px;
                height: 40px;
                background: rgba(255, 255, 255, 0.2);
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 20px;
            }
            .content { 
                background: white; 
                padding: 40px 30px; 
            }
            .code-box { 
                background: linear-gradient(135deg, #f8fafc, #e2e8f0); 
                border: 3px solid #8B5CF6; 
                border-radius: 16px; 
                padding: 30px; 
                text-align: center; 
                margin: 30px 0; 
                position: relative;
            }
            .code-box::before {
                content: '🔐';
                position: absolute;
                top: -15px;
                left: 50%;
                transform: translateX(-50%);
                background: white;
                padding: 0 10px;
                font-size: 24px;
            }
            .verification-code { 
                font-size: 36px; 
                font-weight: bold; 
                color: #8B5CF6; 
                letter-spacing: 12px; 
                margin: 15px 0; 
                font-family: 'Courier New', monospace;
                background: white;
                padding: 15px;
                border-radius: 8px;
                border: 2px dashed #8B5CF6;
            }
            .button { 
                display: inline-block; 
                background: linear-gradient(135deg, #8B5CF6, #EC4899); 
                color: white; 
                padding: 15px 35px; 
                text-decoration: none; 
                border-radius: 30px; 
                font-weight: bold; 
                margin: 25px 0; 
                transition: transform 0.2s;
            }
            .button:hover {
                transform: translateY(-2px);
            }
            .footer { 
                text-align: center; 
                margin-top: 30px; 
                padding: 30px; 
                border-top: 1px solid #e2e8f0; 
                color: #64748b; 
                font-size: 14px; 
                background: #f8fafc;
            }
            .warning { 
                background: linear-gradient(135deg, #FEF3C7, #FDE68A); 
                border-left: 4px solid #F59E0B; 
                padding: 20px; 
                margin: 25px 0; 
                border-radius: 8px; 
            }
            .feature-list {
                background: #f8fafc;
                padding: 20px;
                border-radius: 8px;
                margin: 20px 0;
            }
            .feature-item {
                display: flex;
                align-items: center;
                margin: 10px 0;
                font-size: 14px;
            }
            .feature-icon {
                margin-right: 10px;
                font-size: 16px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <div class="logo">
                    <div class="logo-icon">🌍</div>
                    Universe
                </div>
                <p style="margin: 0; opacity: 0.9;">Global Issue Resolution Platform</p>
            </div>
            
            <div class="content">
                <h2 style="color: #1e293b; margin-bottom: 20px;">Hello ${userName}! 👋</h2>
                <p style="font-size: 16px; color: #475569;">Welcome to Universe! We're excited to have you join our community of citizens working together to resolve issues and improve communities worldwide.</p>
                
                <p style="font-size: 16px; color: #475569;">To complete your account setup and start reporting issues, please verify your email address using the code below:</p>
                
                <div class="code-box">
                    <p style="margin: 0; font-size: 16px; color: #64748b; font-weight: 600;">Your Verification Code:</p>
                    <div class="verification-code">${code}</div>
                    <p style="margin: 0; font-size: 14px; color: #64748b;">Enter this code in the app to verify your account</p>
                </div>
                
                <div class="warning">
                    <strong style="color: #92400e;">⚠️ Important Security Information:</strong>
                    <ul style="margin: 15px 0; color: #92400e;">
                        <li>This code will expire in <strong>10 minutes</strong></li>
                        <li>Never share this code with anyone</li>
                        <li>Universe staff will never ask for this code</li>
                        <li>If you didn't create an account, please ignore this email</li>
                    </ul>
                </div>
                
                <h3 style="color: #1e293b; margin-top: 30px;">🚀 What's Next?</h3>
                <p style="color: #475569;">Once verified, you'll be able to:</p>
                
                <div class="feature-list">
                    <div class="feature-item">
                        <span class="feature-icon">📸</span>
                        <span>Report issues with photo evidence and GPS location</span>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">🏛️</span>
                        <span>Connect directly with government authorities (KURA, KENHAA, MPs)</span>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">🔔</span>
                        <span>Get real-time updates on your reports</span>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">🤝</span>
                        <span>Collaborate with your community on local issues</span>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">📊</span>
                        <span>Track your impact and community contributions</span>
                    </div>
                </div>
                
                <div style="text-align: center; margin: 30px 0;">
                    <p style="color: #475569; margin-bottom: 15px;">Need help? We're here for you!</p>
                    <p style="color: #475569; font-size: 14px;">Reply to this email or contact our support team</p>
                </div>
                
                <div style="border-top: 1px solid #e2e8f0; padding-top: 25px; margin-top: 30px;">
                    <p style="color: #475569; margin-bottom: 5px;">Best regards,</p>
                    <p style="color: #1e293b; font-weight: bold; margin: 0;">ALLOCIOUS KIPROP</p>
                    <p style="color: #64748b; font-size: 14px; margin: 5px 0;">CEO & Founder, Universe</p>
                    <p style="color: #64748b; font-size: 14px; margin: 0;">
                        <a href="mailto:${this.fromEmail}" style="color: #8B5CF6; text-decoration: none;">${this.fromEmail}</a>
                    </p>
                </div>
            </div>
            
            <div class="footer">
                <p style="margin: 0 0 10px 0;">© 2024 Universe - Global Issue Resolution Platform</p>
                <p style="margin: 0; font-size: 12px;">CEO: ALLOCIOUS KIPROP | <a href="mailto:${this.fromEmail}" style="color: #8B5CF6; text-decoration: none;">${this.fromEmail}</a></p>
                <p style="margin: 10px 0 0 0; font-size: 12px; color: #94a3b8;">This email was sent from an automated system. Please do not reply directly to this email.</p>
            </div>
        </div>
    </body>
    </html>
    `
  }

  private getWelcomeEmailTemplate(userName: string): string {
    return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to Universe!</title>
        <style>
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                line-height: 1.6; 
                color: #333; 
                max-width: 600px; 
                margin: 0 auto; 
                padding: 0; 
                background-color: #f0fdf4;
            }
            .container {
                background: white;
                border-radius: 12px;
                overflow: hidden;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                margin: 20px;
            }
            .header { 
                background: linear-gradient(135deg, #10B981, #3B82F6); 
                color: white; 
                padding: 40px 30px; 
                text-align: center; 
            }
            .logo { 
                font-size: 32px; 
                font-weight: bold; 
                margin-bottom: 10px; 
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
            }
            .logo-icon {
                width: 40px;
                height: 40px;
                background: rgba(255, 255, 255, 0.2);
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 20px;
            }
            .content { 
                background: white; 
                padding: 40px 30px; 
            }
            .success-box { 
                background: linear-gradient(135deg, #D1FAE5, #A7F3D0); 
                border: 3px solid #10B981; 
                border-radius: 16px; 
                padding: 30px; 
                text-align: center; 
                margin: 30px 0; 
                position: relative;
            }
            .success-box::before {
                content: '🎉';
                position: absolute;
                top: -15px;
                left: 50%;
                transform: translateX(-50%);
                background: white;
                padding: 0 10px;
                font-size: 24px;
            }
            .button { 
                display: inline-block; 
                background: linear-gradient(135deg, #10B981, #3B82F6); 
                color: white; 
                padding: 15px 35px; 
                text-decoration: none; 
                border-radius: 30px; 
                font-weight: bold; 
                margin: 25px 0; 
                transition: transform 0.2s;
            }
            .button:hover {
                transform: translateY(-2px);
            }
            .footer { 
                text-align: center; 
                margin-top: 30px; 
                padding: 30px; 
                border-top: 1px solid #e2e8f0; 
                color: #64748b; 
                font-size: 14px; 
                background: #f0fdf4;
            }
            .feature-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 15px;
                margin: 20px 0;
            }
            .feature-card {
                background: #f8fafc;
                padding: 15px;
                border-radius: 8px;
                border-left: 4px solid #10B981;
            }
            .feature-title {
                font-weight: bold;
                color: #1e293b;
                margin-bottom: 5px;
            }
            .feature-desc {
                font-size: 13px;
                color: #64748b;
            }
            .stats-row {
                display: flex;
                justify-content: space-around;
                background: #f8fafc;
                padding: 20px;
                border-radius: 8px;
                margin: 20px 0;
            }
            .stat-item {
                text-align: center;
            }
            .stat-number {
                font-size: 24px;
                font-weight: bold;
                color: #10B981;
            }
            .stat-label {
                font-size: 12px;
                color: #64748b;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <div class="logo">
                    <div class="logo-icon">🌍</div>
                    Welcome to Universe!
                </div>
                <p style="margin: 0; opacity: 0.9;">Your account is now active and ready to use</p>
            </div>
            
            <div class="content">
                <div class="success-box">
                    <h2 style="color: #10B981; margin: 0 0 10px 0;">✅ Account Verified Successfully!</h2>
                    <p style="margin: 0; color: #059669; font-weight: 500;">You're now part of the Universe community</p>
                </div>
                
                <h2 style="color: #1e293b;">Hello ${userName}! 🚀</h2>
                <p style="font-size: 16px; color: #475569;">Congratulations! Your Universe account has been successfully verified and is now ready to use. You're joining a global community of citizens making real change in their communities.</p>
                
                <div class="stats-row">
                    <div class="stat-item">
                        <div class="stat-number">50K+</div>
                        <div class="stat-label">Issues Resolved</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">120+</div>
                        <div class="stat-label">Countries</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">1M+</div>
                        <div class="stat-label">Active Users</div>
                    </div>
                </div>
                
                <h3 style="color: #1e293b;">🚀 Get Started:</h3>
                <div class="feature-grid">
                    <div class="feature-card">
                        <div class="feature-title">📸 Report Issues</div>
                        <div class="feature-desc">Take photos and report community problems with GPS location</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-title">🔍 Explore</div>
                        <div class="feature-desc">See what others in your community are reporting</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-title">📊 Track Progress</div>
                        <div class="feature-desc">Follow up on your reports and see resolutions</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-title">🤝 Make Impact</div>
                        <div class="feature-desc">Help improve your community and beyond</div>
                    </div>
                </div>
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="https://universe-app.vercel.app/home" class="button">
                        🌍 Start Using Universe →
                    </a>
                </div>
                
                <h3 style="color: #1e293b;">📞 Need Support?</h3>
                <p style="color: #475569;">Our team is here to help you get the most out of Universe:</p>
                <ul style="color: #475569;">
                    <li>📧 Email: <a href="mailto:${this.fromEmail}" style="color: #10B981; text-decoration: none;">${this.fromEmail}</a></li>
                    <li>💬 Help Center: <a href="https://universe-app.vercel.app/help" style="color: #10B981; text-decoration: none;">Visit Help Center</a></li>
                    <li>📱 Community: Join our user community for tips and updates</li>
                </ul>
                
                <div style="background: linear-gradient(135deg, #f0f9ff, #e0f2fe); padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #3B82F6;">
                    <p style="margin: 0; color: #1e40af; font-weight: 500;">💡 Pro Tip: Start by exploring issues in your area to see how Universe works, then report your first issue to make an immediate impact!</p>
                </div>
                
                <p style="color: #475569; font-size: 16px;">Thank you for joining Universe. Together, we're making communities better, one report at a time!</p>
                
                <div style="border-top: 1px solid #e2e8f0; padding-top: 25px; margin-top: 30px;">
                    <p style="color: #475569; margin-bottom: 5px;">Best regards,</p>
                    <p style="color: #1e293b; font-weight: bold; margin: 0;">ALLOCIOUS KIPROP</p>
                    <p style="color: #64748b; font-size: 14px; margin: 5px 0;">CEO & Founder, Universe</p>
                    <p style="color: #64748b; font-size: 14px; margin: 0;">
                        <a href="mailto:${this.fromEmail}" style="color: #10B981; text-decoration: none;">${this.fromEmail}</a>
                    </p>
                </div>
            </div>
            
            <div class="footer">
                <p style="margin: 0 0 10px 0;">© 2024 Universe - Global Issue Resolution Platform</p>
                <p style="margin: 0; font-size: 12px;">CEO: ALLOCIOUS KIPROP | <a href="mailto:${this.fromEmail}" style="color: #10B981; text-decoration: none;">${this.fromEmail}</a></p>
                <p style="margin: 10px 0 0 0; font-size: 12px; color: #94a3b8;">You're receiving this because you successfully created a Universe account.</p>
            </div>
        </div>
    </body>
    </html>
    `
  }
}

export const emailService = EmailService.getInstance()
