# Universe App - Email Verification Setup

## 🚀 Quick Start

### 1. Install Dependencies
\`\`\`bash
npm install
\`\`\`

### 2. Environment Setup
Create a `.env.local` file in your project root:

\`\`\`env
RESEND_API_KEY=re_Pd79efJV_K7yZMbjBTbXPGWy5omyqHoW1
ADMIN_EMAIL=txichub39@gmail.com
NEXT_PUBLIC_APP_URL=https://universe-app.vercel.app
NODE_ENV=development
\`\`\`

### 3. Start Development Server
\`\`\`bash
npm run dev
\`\`\`

### 4. Test the Email System
1. Go to `http://localhost:3000/login`
2. Click "Sign up"
3. Fill in the registration form
4. Submit and check your email for verification code
5. Enter the code to complete registration

## 📧 Email Features

### Verification Email
- **From:** Universe Admin <txichub39@gmail.com>
- **Subject:** 🌍 Verify Your Universe Account - Action Required
- **Content:** Professional HTML template with 6-digit code
- **Expiry:** 10 minutes

### Welcome Email
- **From:** Universe Team <txichub39@gmail.com>
- **Subject:** 🎉 Welcome to Universe - Your Account is Ready!
- **Content:** Welcome message with getting started guide
- **Sent:** After successful verification

## 🔧 API Endpoints

### POST /api/send-verification
Sends verification email with 6-digit code
\`\`\`json
{
  "email": "user@example.com",
  "code": "123456",
  "userName": "John Doe"
}
\`\`\`

### POST /api/send-welcome
Sends welcome email after verification
\`\`\`json
{
  "email": "user@example.com",
  "userName": "John Doe"
}
\`\`\`

## 🎯 User Flow

1. **Sign Up:** User enters name, email, password
2. **Email Sent:** Verification code sent to user's email
3. **Verification:** User enters 6-digit code
4. **Welcome:** Welcome email sent automatically
5. **Redirect:** User redirected to home page

## 🔒 Admin Access

- **Email:** txichub39@gmail.com
- **Access:** Admin dashboard at `/admin`
- **Features:** User management, issue tracking, partner registration

## 🚀 Deployment

### Vercel Deployment
1. Push code to GitHub
2. Connect to Vercel
3. Add environment variables:
   - `RESEND_API_KEY`
   - `ADMIN_EMAIL`
   - `NEXT_PUBLIC_APP_URL`
4. Deploy

### Environment Variables for Production
\`\`\`env
RESEND_API_KEY=re_Pd79efJV_K7yZMbjBTbXPGWy5omyqHoW1
ADMIN_EMAIL=txichub39@gmail.com
NEXT_PUBLIC_APP_URL=https://your-domain.vercel.app
NODE_ENV=production
\`\`\`

## 🔍 Troubleshooting

### Emails Not Received
1. Check spam/junk folder
2. Verify API key in environment variables
3. Check Resend dashboard for delivery status
4. Ensure sender email is verified in Resend

### Verification Code Issues
- Codes expire after 10 minutes
- Use "Send New Code" button for fresh code
- Check console for API errors

### Admin Access Issues
- Must use exact email: txichub39@gmail.com
- Clear browser storage if needed
- Check localStorage for userRole and userEmail

## 📊 Features Included

✅ Real email verification with Resend
✅ Professional HTML email templates
✅ Admin dashboard with partner management
✅ User authentication and role management
✅ Issue reporting and tracking
✅ Responsive design for all devices
✅ Error handling and user feedback

## 🎨 Customization

### Email Templates
- Edit templates in `lib/email-service.ts`
- Customize branding, colors, and content
- Add your logo and company information

### Styling
- Tailwind CSS for all styling
- Responsive design included
- Easy to customize colors and layout

## 📞 Support

For issues or questions:
- Email: txichub39@gmail.com
- Check console logs for errors
- Review Resend dashboard for email delivery
\`\`\`

Finally, let me create a simple test script to verify the email service:
