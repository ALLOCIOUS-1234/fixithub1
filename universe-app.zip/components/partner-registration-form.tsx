"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CheckCircle, Building, Globe, Mail, Phone, MapPin } from "lucide-react"

interface PartnerFormData {
  name: string
  acronym: string
  type: string
  category: string
  description: string
  contactEmail: string
  contactPhone: string
  website: string
  jurisdiction: string
  address: string
}

interface PartnerRegistrationFormProps {
  onSubmit: (data: PartnerFormData) => Promise<void>
  onCancel: () => void
  isLoading: boolean
}

export function PartnerRegistrationForm({ onSubmit, onCancel, isLoading }: PartnerRegistrationFormProps) {
  const [formData, setFormData] = useState<PartnerFormData>({
    name: "",
    acronym: "",
    type: "",
    category: "",
    description: "",
    contactEmail: "",
    contactPhone: "",
    website: "",
    jurisdiction: "",
    address: "",
  })

  const [errors, setErrors] = useState<Partial<PartnerFormData>>({})

  const validateForm = (): boolean => {
    const newErrors: Partial<PartnerFormData> = {}

    if (!formData.name.trim()) newErrors.name = "Partner name is required"
    if (!formData.acronym.trim()) newErrors.acronym = "Acronym is required"
    if (!formData.type) newErrors.type = "Partner type is required"
    if (!formData.category) newErrors.category = "Service category is required"
    if (!formData.contactEmail.trim()) newErrors.contactEmail = "Contact email is required"

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (formData.contactEmail && !emailRegex.test(formData.contactEmail)) {
      newErrors.contactEmail = "Please enter a valid email address"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    try {
      await onSubmit(formData)
      // Reset form on success
      setFormData({
        name: "",
        acronym: "",
        type: "",
        category: "",
        description: "",
        contactEmail: "",
        contactPhone: "",
        website: "",
        jurisdiction: "",
        address: "",
      })
      setErrors({})
    } catch (error) {
      console.error("Failed to submit partner registration:", error)
    }
  }

  const handleInputChange = (field: keyof PartnerFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }))
    }
  }

  return (
    <Card className="border-2 border-purple-200">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
        <CardTitle className="flex items-center gap-2">
          <Building className="w-5 h-5 text-purple-600" />
          Register New Government Partner
        </CardTitle>
        <p className="text-sm text-gray-600">Add a new government authority or agency to receive issue reports</p>
      </CardHeader>

      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 border-b pb-2">Basic Information</h3>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="partnerName" className="flex items-center gap-1">
                  <Building className="w-4 h-4" />
                  Partner Name *
                </Label>
                <Input
                  id="partnerName"
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  placeholder="e.g., Kenya Urban Roads Authority"
                  className={errors.name ? "border-red-500" : ""}
                />
                {errors.name && <p className="text-sm text-red-600">{errors.name}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="partnerAcronym">Acronym *</Label>
                <Input
                  id="partnerAcronym"
                  value={formData.acronym}
                  onChange={(e) => handleInputChange("acronym", e.target.value.toUpperCase())}
                  placeholder="e.g., KURA"
                  className={errors.acronym ? "border-red-500" : ""}
                />
                {errors.acronym && <p className="text-sm text-red-600">{errors.acronym}</p>}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Partner Type *</Label>
                <Select value={formData.type} onValueChange={(value) => handleInputChange("type", value)}>
                  <SelectTrigger className={errors.type ? "border-red-500" : ""}>
                    <SelectValue placeholder="Select partner type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="government">Government Agency</SelectItem>
                    <SelectItem value="ministry">Ministry</SelectItem>
                    <SelectItem value="authority">Authority</SelectItem>
                    <SelectItem value="county">County Government</SelectItem>
                    <SelectItem value="parliament">Parliamentary Office</SelectItem>
                    <SelectItem value="utility">Utility Company</SelectItem>
                    <SelectItem value="parastatal">Parastatal</SelectItem>
                  </SelectContent>
                </Select>
                {errors.type && <p className="text-sm text-red-600">{errors.type}</p>}
              </div>

              <div className="space-y-2">
                <Label>Service Category *</Label>
                <Select value={formData.category} onValueChange={(value) => handleInputChange("category", value)}>
                  <SelectTrigger className={errors.category ? "border-red-500" : ""}>
                    <SelectValue placeholder="Select service category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="roads">Roads & Infrastructure</SelectItem>
                    <SelectItem value="waste">Waste Management</SelectItem>
                    <SelectItem value="water">Water & Sanitation</SelectItem>
                    <SelectItem value="health">Health Services</SelectItem>
                    <SelectItem value="education">Education</SelectItem>
                    <SelectItem value="security">Security</SelectItem>
                    <SelectItem value="mp">MP Office</SelectItem>
                    <SelectItem value="housing">Housing</SelectItem>
                    <SelectItem value="transport">Transport</SelectItem>
                    <SelectItem value="environment">Environment</SelectItem>
                    <SelectItem value="general">General Services</SelectItem>
                  </SelectContent>
                </Select>
                {errors.category && <p className="text-sm text-red-600">{errors.category}</p>}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="partnerDescription">Description</Label>
              <Textarea
                id="partnerDescription"
                value={formData.description}
                onChange={(e) => handleInputChange("description", e.target.value)}
                placeholder="Brief description of the partner's role and responsibilities"
                rows={3}
              />
            </div>
          </div>

          {/* Contact Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 border-b pb-2">Contact Information</h3>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="contactEmail" className="flex items-center gap-1">
                  <Mail className="w-4 h-4" />
                  Contact Email *
                </Label>
                <Input
                  id="contactEmail"
                  type="email"
                  value={formData.contactEmail}
                  onChange={(e) => handleInputChange("contactEmail", e.target.value)}
                  placeholder="official@partner.go.ke"
                  className={errors.contactEmail ? "border-red-500" : ""}
                />
                {errors.contactEmail && <p className="text-sm text-red-600">{errors.contactEmail}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="contactPhone" className="flex items-center gap-1">
                  <Phone className="w-4 h-4" />
                  Contact Phone
                </Label>
                <Input
                  id="contactPhone"
                  type="tel"
                  value={formData.contactPhone}
                  onChange={(e) => handleInputChange("contactPhone", e.target.value)}
                  placeholder="+254 700 000 000"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="website" className="flex items-center gap-1">
                  <Globe className="w-4 h-4" />
                  Official Website
                </Label>
                <Input
                  id="website"
                  type="url"
                  value={formData.website}
                  onChange={(e) => handleInputChange("website", e.target.value)}
                  placeholder="https://www.partner.go.ke"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="jurisdiction" className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  Jurisdiction/Coverage
                </Label>
                <Input
                  id="jurisdiction"
                  value={formData.jurisdiction}
                  onChange={(e) => handleInputChange("jurisdiction", e.target.value)}
                  placeholder="e.g., Nationwide, Nairobi County, etc."
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address" className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                Physical Address
              </Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => handleInputChange("address", e.target.value)}
                placeholder="Complete physical address including postal code"
                rows={2}
              />
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex gap-3 pt-4 border-t">
            <Button
              type="submit"
              className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Registering...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Register Partner
                </>
              )}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
