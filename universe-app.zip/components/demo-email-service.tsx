"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Mail, Copy, CheckCircle } from "lucide-react"

interface EmailServiceProps {
  email: string
  verificationCode: string
  onClose: () => void
}

export function DemoEmailService({ email, verificationCode, onClose }: EmailServiceProps) {
  const [copied, setCopied] = useState(false)

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(verificationCode)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("Failed to copy code:", err)
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Mail className="w-6 h-6 text-blue-600" />
          </div>
          <CardTitle>Demo Email Service</CardTitle>
          <Badge className="bg-blue-100 text-blue-800">Development Mode</Badge>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600 mb-2">
              <strong>To:</strong> {email}
            </p>
            <p className="text-sm text-gray-600 mb-2">
              <strong>From:</strong> Universe Support &lt;noreply@universe.com&gt;
            </p>
            <p className="text-sm text-gray-600 mb-4">
              <strong>Subject:</strong> Verify Your Universe Account
            </p>

            <div className="border-l-4 border-purple-500 pl-4">
              <h3 className="font-semibold mb-2">Welcome to Universe!</h3>
              <p className="text-sm text-gray-700 mb-4">
                Thank you for joining Universe. To complete your account setup, please use the verification code below:
              </p>

              <div className="bg-white p-3 rounded border text-center">
                <p className="text-xs text-gray-500 mb-1">Your verification code:</p>
                <p className="text-2xl font-bold tracking-widest text-purple-600">{verificationCode}</p>
              </div>

              <p className="text-xs text-gray-500 mt-4">
                This code will expire in 10 minutes. If you didn't create an account, please ignore this email.
              </p>
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={copyCode} variant="outline" className="flex-1 bg-transparent">
              {copied ? <CheckCircle className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
              {copied ? "Copied!" : "Copy Code"}
            </Button>
            <Button onClick={onClose} className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500">
              Got it!
            </Button>
          </div>

          <p className="text-xs text-gray-500 text-center">
            In production, this would be sent to your actual email address.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
